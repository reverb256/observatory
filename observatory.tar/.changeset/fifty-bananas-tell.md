---
'@maplespike/api-server': minor
---

feat: add email service (SendGrid + console fallback), onboarding checklist API, and portal UI (#44)
