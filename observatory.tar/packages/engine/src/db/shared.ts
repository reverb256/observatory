// Unified DatabaseService — re-export from shared @maplespike/database package
export * from '@maplespike/database';