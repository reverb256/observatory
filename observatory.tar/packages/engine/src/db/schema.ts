// Schema definitions — re-exported from shared @maplespike/database package
export * from '@maplespike/database/schema';
