/**
 * Entity Resolution Engine — barrel export
 */

export { AliasManager } from "./aliases";
export { EntityResolver } from "./resolver";
export type {
  AliasEntry,
  ConfidenceLevel,
  ResolutionMap,
  ResolutionResult,
  ResolvedEntity,
} from "./types";
