/**
 * MapleSpike MCP Server — core protocol implementation
 *
 * Implements the Model Context Protocol (MCP) over stdio and SSE transports.
 * JSON-RPC 2.0 based, supporting tools/list and tools/call methods.
 */

import type { ToolDefinition, ToolHandler, ToolResponse } from './tools/types.js';

// ─── Types ──────────────────────────────────────────────────────────────

interface JsonRpcRequest {
  jsonrpc: '2.0';
  id?: string | number;
  method: string;
  params?: Record<string, unknown>;
}

interface JsonRpcResponse {
  jsonrpc: '2.0';
  id: string | number | null;
  result?: unknown;
  error?: { code: number; message: string; data?: unknown };
}

interface ServerCapabilities {
  experimental?: Record<string, unknown>;
  tools?: Record<string, unknown>;
  resources?: Record<string, unknown>;
  prompts?: Record<string, unknown>;
}

// ─── Logging ────────────────────────────────────────────────────────────

function log(level: 'info' | 'warn' | 'error', msg: string, ...args: unknown[]) {
  // stderr so it doesn't interfere with stdio transport
  console.error(`[maplespike-mcp] ${level}: ${msg}`, ...args.map(a => typeof a === 'string' ? a : JSON.stringify(a)));
}

// ─── Output Sanitization ─────────────────────────────────────────────────
// OWASP LLM07: Insecure Output Handling — strip dangerous content before
// returning tool results to MCP clients (AI agents).

function sanitizeString(val: string): string {
  let s = val;
  // Remove <script> and </script> tags (case-insensitive)
  s = s.replace(/<script\b[^>]*>/gi, '');
  s = s.replace(/<\/script\s*>/gi, '');
  // Remove javascript: protocol from URLs
  s = s.replace(/\bjavascript\s*:/gi, '');
  // Remove data: protocol from URLs (unless a known safe image type)
  s = s.replace(/\bdata:(?!image\/(?:png|jpe?g|gif|webp|svg\+xml))/gi, '');
  // Truncate to 100,000 chars max
  if (s.length > 100000) {
    s = s.slice(0, 100000);
  }
  return s;
}

function sanitizeValue(value: unknown): unknown {
  if (typeof value === 'string') {
    return sanitizeString(value);
  }
  if (Array.isArray(value)) {
    return value.map(v => sanitizeValue(v));
  }
  if (value !== null && typeof value === 'object') {
    const result: Record<string, unknown> = {};
    for (const [key, v] of Object.entries(value as Record<string, unknown>)) {
      result[key] = sanitizeValue(v);
    }
    return result;
  }
  return value;
}

function sanitizeOutput(response: ToolResponse): ToolResponse {
  const content = response.content;
  let sanitized: ToolResponse['content'];

  if (typeof content === 'string') {
    sanitized = sanitizeString(content);
  } else if (Array.isArray(content)) {
    sanitized = content.map(item => sanitizeValue(item)) as Record<string, unknown>[];
  } else {
    sanitized = sanitizeValue(content ?? {}) as Record<string, unknown>;
  }

  return { ...response, content: sanitized };
}

// ─── MCP Server ─────────────────────────────────────────────────────────

export class McpServer {
  private tools = new Map<string, { definition: ToolDefinition; handler: ToolHandler }>();
  private initialized = false;
  private clientCapabilities: Record<string, unknown> = {};
  private serverVersion = '0.1.0';
  private serverName = 'maplespike-canada-mcp';

  // ── Tool registration ─────────────────────────────────────────────────

  registerTool(definition: ToolDefinition, handler: ToolHandler): void {
    this.tools.set(definition.name, { definition, handler });
    log('info', `Registered tool: ${definition.name}`);
  }

  // ── Incoming message handling ──────────────────────────────────────────

  async handleMessage(
    raw: unknown,
    locale: string,
    send: (response: JsonRpcResponse) => void,
  ): Promise<void> {
    const msg = this.parseMessage(raw, send);
    if (!msg) return;

    const { method, id, params } = msg;

    switch (method) {
      case 'initialize':
        this.handleInitialize(id, params, send);
        break;
      case 'notifications/initialized':
        this.initialized = true;
        log('info', 'Client initialized');
        // Notifications don't have an id — no response
        break;
      case 'tools/list':
        this.handleToolsList(id, locale, send);
        break;
      case 'tools/call':
        await this.handleToolCall(id, params, send);
        break;
      default:
        if (id != null) {
          send(this.error(id, -32601, `Method not found: ${method}`));
        }
    }
  }

  private parseMessage(
    raw: unknown,
    send: (r: JsonRpcResponse) => void,
  ): JsonRpcRequest | null {
    if (typeof raw !== 'object' || raw === null) {
      send(this.error(null, -32700, 'Parse error: expected object'));
      return null;
    }

    const msg = raw as Record<string, unknown>;

    if (msg.jsonrpc !== '2.0' || typeof msg.method !== 'string') {
      send(this.error(
        (msg.id as string | number) ?? null,
        -32600,
        'Invalid Request: must have jsonrpc: "2.0" and method: string',
      ));
      return null;
    }

    return {
      jsonrpc: '2.0',
      id: (msg.id as string | number) ?? undefined,
      method: msg.method as string,
      params: msg.params as Record<string, unknown> | undefined,
    };
  }

  // ── method handlers ───────────────────────────────────────────────────

  private handleInitialize(
    id: string | number | undefined,
    params: Record<string, unknown> | undefined,
    send: (r: JsonRpcResponse) => void,
  ): void {
    this.clientCapabilities = (params?.capabilities as Record<string, unknown>) ?? {};

    log('info', `Initialize: protocolVersion=${params?.protocolVersion ?? 'unknown'}`);

    const capabilities: ServerCapabilities = {
      tools: {}, // tools/list is supported
    };

    send(this.result(id ?? null, {
      protocolVersion: params?.protocolVersion ?? '2025-03-26',
      capabilities,
      serverInfo: {
        name: this.serverName,
        version: this.serverVersion,
      },
    }));
  }

  private handleToolsList(
    id: string | number | undefined,
    locale: string,
    send: (r: JsonRpcResponse) => void,
  ): void {
    const definitions: ToolDefinition[] = [];
    for (const { definition } of this.tools.values()) {
      const localized = { ...definition };
      if (localized.descriptions?.[locale]) {
        localized.description = localized.descriptions[locale];
      }
      delete (localized as any).descriptions;
      definitions.push(localized);
    }

    send(this.result(id ?? null, { tools: definitions }));
  }

  private async handleToolCall(
    id: string | number | undefined,
    params: Record<string, unknown> | undefined,
    send: (r: JsonRpcResponse) => void,
  ): Promise<void> {
    const toolName = params?.name as string | undefined;
    const args = (params?.arguments as Record<string, unknown>) ?? {};

    if (!toolName) {
      send(this.error(id ?? null, -32602, 'Invalid params: must include "name"'));
      return;
    }

    const tool = this.tools.get(toolName);
    if (!tool) {
      send(this.error(id ?? null, -32602, `Unknown tool: ${toolName}`));
      return;
    }

    // Validate arguments against the tool's inputSchema
    const validationErrors = validateToolArgs(args, tool.definition.inputSchema);
    if (validationErrors.length > 0) {
      send(this.result(id ?? null, {
        content: [{ type: 'text', text: validationErrors.join('\n') }],
        isError: true,
      }));
      return;
    }

    // Run handler; catch sync and async errors
    try {
      const rawResult: ToolResponse = await tool.handler(args);
      const result: ToolResponse = sanitizeOutput(rawResult);

      // MCP tool result envelope
      // content is an array of text|image|resource items
      send(this.result(id ?? null, {
        content: [
          {
            type: 'text',
            text: typeof result.content === 'string'
              ? result.content
              : JSON.stringify(result.content, null, 2),
          },
        ],
        isError: result.isError ?? false,
      }));
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      send(this.result(id ?? null, {
        content: [{ type: 'text', text: `Error: ${msg}` }],
        isError: true,
      }));
    }
  }

  // ── JSON-RPC helpers ──────────────────────────────────────────────────

  private result(id: string | number | null, result: unknown): JsonRpcResponse {
    return { jsonrpc: '2.0', id, result };
  }

  private error(id: string | number | null, code: number, message: string, data?: unknown): JsonRpcResponse {
    return { jsonrpc: '2.0', id, error: { code, message, data } };
  }

  // ── Notification helpers (for server->client) ─────────────────────────

  makeNotification(method: string, params?: Record<string, unknown>): string {
    return JSON.stringify({ jsonrpc: '2.0', method, params });
  }

  // ── Helpers ───────────────────────────────────────────────────────────

  getToolCount(): number {
    return this.tools.size;
  }
}

// ─── Runtime argument validation ─────────────────────────────────────

/**
 * Validate tool call arguments against the tool's inputSchema.
 * Returns an array of error messages (empty = valid).
 */
function validateToolArgs(
  args: Record<string, unknown>,
  schema: ToolDefinition['inputSchema'],
): string[] {
  const errors: string[] = [];
  const properties = schema.properties ?? {};
  const required = schema.required ?? [];

  // Check required fields are present and non-empty strings
  for (const field of required) {
    const value = args[field];
    if (value === undefined || value === null || value === '') {
      errors.push(`Missing required field: "${field}"`);
    }
  }

  // Check type constraints and other validations per property
  for (const [key, value] of Object.entries(args)) {
    if (value === undefined || value === null) continue;

    const prop = properties[key] as Record<string, unknown> | undefined;
    if (!prop) continue; // Unknown property — skip validation

    const propType = prop.type as string | undefined;
    const propEnum = prop.enum as string[] | undefined;
    const propMinimum = prop.minimum as number | undefined;
    const propMaximum = prop.maximum as number | undefined;

    // Type check
    if (propType === 'string' && typeof value !== 'string') {
      errors.push(`Invalid type for "${key}": expected string, got ${typeof value}`);
    } else if (propType === 'number' && typeof value !== 'number') {
      errors.push(`Invalid type for "${key}": expected number, got ${typeof value}`);
    }

    // Enum check (for string values)
    if (propEnum && typeof value === 'string' && !propEnum.includes(value)) {
      errors.push(
        `Invalid value for "${key}": expected one of [${propEnum.join(', ')}], got "${value}"`,
      );
    }

    // Minimum / maximum for numbers
    if (propType === 'number' && typeof value === 'number') {
      if (propMinimum !== undefined && value < propMinimum) {
        errors.push(`Invalid value for "${key}": ${value} is less than minimum ${propMinimum}`);
      }
      if (propMaximum !== undefined && value > propMaximum) {
        errors.push(`Invalid value for "${key}": ${value} is greater than maximum ${propMaximum}`);
      }
    }
  }

  return errors;
}
