export const GEOSPATIAL_UA = 'MapleSpike-Geospatial/1.0';
export const GEOSPATIAL_TIMEOUT_MS = 15_000;
export const MAX_GEOSPATIAL_RECORDS = 300;
export const CKAN_BASE = 'https://open.canada.ca/data/api/3/action';

export const GEOSPATIAL_QUERIES = [
  'geospatial',
  'geographic',
  'addresses',
  'buildings',
  'administrative boundaries',
  'land parcels',
  'municipal boundaries',
  'transportation network',
  'water features',
  'topographic',
  'LODE',
  'ABFS',
  'cadastre',
  'zoning',
  'land use',
  'forest inventory',
  'wetlands',
  'flood plains',
];
