/**
 * IRCC Express Entry Parser — MapleSpike Pipeline
 *
 * Parse raw Express Entry data into standardized records.
 */

import { createHash } from 'node:crypto';
import type {
  ExpressEntryRecord,
  ExpressEntryPoolStats,
  RawExpressEntryRound,
} from './types.js';

/* ------------------------------------------------------------------ */
/*  SHA-256 Hashing                                                   */
/* ------------------------------------------------------------------ */

function sha256(content: string): string {
  return createHash('sha256').update(content).digest('hex');
}

/* ------------------------------------------------------------------ */
/*  Parsing Functions                                                */
/* ------------------------------------------------------------------ */

/**
 * Parse raw round data into ExpressEntryRecord.
 *
 * @param round - Raw round data from fetcher
 * @param sourceUrl - Source URL for provenance
 * @returns Parsed ExpressEntryRecord
 */
export function parseExpressEntryRound(
  round: RawExpressEntryRound,
  sourceUrl: string
): ExpressEntryRecord {
  const content = JSON.stringify(round);

  return {
    id: sha256(content),
    drawNumber: round.drawNumber,
    drawDate: round.drawDate,
    cutoffScore: round.cutoffScore,
    invitationsIssued: round.invitationsIssued,
    programStream: round.programStream,
    tieBreakDate: round.tieBreakDate ?? null,
    isTargeted: round.programStream !== 'all',
    ingestedAt: new Date().toISOString(),
    sourceUrl,
  };
}

/**
 * Parse pool statistics into ExpressEntryPoolStats.
 *
 * @param stats - Raw pool statistics from fetcher
 * @param sourceUrl - Source URL for provenance
 * @returns Parsed ExpressEntryPoolStats
 */
export function parseExpressEntryPoolStats(
  stats: Record<string, number>,
  sourceUrl: string
): ExpressEntryPoolStats {
  const content = JSON.stringify(stats);

  return {
    id: sha256(content),
    snapshotDate: new Date().toISOString(),
    totalCandidates: stats.total ?? 0,
    crs400_441: stats['400-441'] ?? 0,
    crs442_449: stats['442-449'] ?? 0,
    crs450_451: stats['450-451'] ?? 0,
    crs452_600: stats['452-600'] ?? 0,
    crs601_1200: stats['601-1200'] ?? 0,
    ingestedAt: new Date().toISOString(),
    sourceUrl,
  };
}