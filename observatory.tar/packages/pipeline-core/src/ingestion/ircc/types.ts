/**
 * IRCC Express Entry Data Types — MapleSpike Pipeline
 *
 * Express Entry candidate pool, CRS distribution, and draw results.
 * Data from Immigration, Refugees and Citizenship Canada (IRCC).
 *
 * Data License: Open Government Licence - Canada
 * https://open.canada.ca/en/open-government-licence-canada
 */

/* ------------------------------------------------------------------ */
/*  Raw Data Structures (from fetcher)                                */
/* ------------------------------------------------------------------ */

export interface RawExpressEntryRound {
  /** Round number */
  drawNumber: number;
  /** Draw date (various formats) */
  drawDate: string;
  /** CRS score cutoff */
  cutoffScore: number;
  /** Number of invitations */
  invitationsIssued: number;
  /** Program type (all, fsw, cec, fst, pnp) */
  programStream: string;
  /** Tie-breaking rule date */
  tieBreakDate?: string;
}

/* ------------------------------------------------------------------ */
/*  CRS Score Distribution                                            */
/* ------------------------------------------------------------------ */

export interface ExpressEntryRecord {
  /** SHA-256 hash of the row content (primary key) */
  id: string;
  /** Draw number (e.g. 280) */
  drawNumber: number;
  /** Draw date (ISO-8601) */
  drawDate: string;
  /** CRS score cutoff for this draw */
  cutoffScore: number;
  /** Number of invitations issued */
  invitationsIssued: number;
  /** Program stream (all, fsw, cec, fst, pnp) */
  programStream: string;
  /** Tie-breaking rule date (if applicable) */
  tieBreakDate: string | null;
  /** Whether this was a targeted draw */
  isTargeted: boolean;
  /** ISO-8601 ingestion timestamp */
  ingestedAt: string;
  /** Source URL for provenance */
  sourceUrl: string;
}

/* ------------------------------------------------------------------ */
/*  Pool Statistics                                                   */
/* ------------------------------------------------------------------ */

export interface ExpressEntryPoolStats {
  /** SHA-256 hash (primary key) */
  id: string;
  /** Snapshot date (ISO-8601) */
  snapshotDate: string;
  /** Total candidates in pool */
  totalCandidates: number;
  /** Candidates with CRS score 400-441 */
  crs400_441: number;
  /** Candidates with CRS score 442-449 */
  crs442_449: number;
  /** Candidates with CRS score 450-451 */
  crs450_451: number;
  /** Candidates with CRS score 452-600 */
  crs452_600: number;
  /** Candidates with CRS score 601-1200 */
  crs601_1200: number;
  /** ISO-8601 ingestion timestamp */
  ingestedAt: string;
  /** Source URL */
  sourceUrl: string;
}

/* ------------------------------------------------------------------ */
/*  Ingestion Results                                                 */
/* ------------------------------------------------------------------ */

export interface ExpressEntryIngestionResult {
  recordsFound: number;
  recordsIngested: number;
  errors: string[];
  durationMs: number;
}

export interface ExpressEntryAllResult {
  draws: ExpressEntryIngestionResult;
  poolStats: ExpressEntryIngestionResult;
  totalRecords: number;
  totalErrors: number;
  durationMs: number;
}