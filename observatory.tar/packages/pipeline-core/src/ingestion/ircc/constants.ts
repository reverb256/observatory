/**
 * IRCC Express Entry Constants — MapleSpike Pipeline
 *
 * Source URLs and configuration constants for Express Entry data ingestion.
 */

export const IRCC_SOURCES = {
  /** Main Express Entry page */
  BASE: 'https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry.html',
  /** Pool statistics page */
  POOL_STATS: 'https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry/submit-profile/express-entry-pool.html',
  /** Rounds of invitations page */
  ROUNDS: 'https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry/submit-profile/express-entry-rounds.html',
  /** Open Data portal */
  OPEN_DATA: 'https://open.canada.ca/data/en/dataset/b917f4c4-a554-4b43-ba30-433293dfb59f',
} as const;

/* ------------------------------------------------------------------ */
/*  Configuration                                                      */
/* ------------------------------------------------------------------ */

export interface IrccConfig {
  /** Maximum concurrent requests */
  maxConcurrent?: number;
  /** Request timeout in milliseconds */
  timeout?: number;
  /** Enable debug logging */
  debug?: boolean;
}

export const DEFAULT_CONFIG: IrccConfig = {
  maxConcurrent: 5,
  timeout: 30000,
  debug: false,
};