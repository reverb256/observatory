/**
 * IRCC Express Entry Fetcher — MapleSpike Pipeline
 *
 * HTTP fetcher for Express Entry round results and pool statistics.
 *
 * NOTE: IRCC does not provide a public API. This module fetches from Canada.ca
 * HTML pages and parses data from table elements. The fetcher is structured to
 * allow future integration with official APIs if they become available.
 */

import { httpGet } from '../../utils/http.js';
import type { RawExpressEntryRound } from './types.ts';
import { IrccConfig } from './constants.js';
import { IRCC_SOURCES } from './constants.js';

/* ------------------------------------------------------------------ */
/*  Fetching Functions                                                */
/* ------------------------------------------------------------------ */

/**
 * Fetch Express Entry round results from Canada.ca.
 *
 * @param config - Fetch configuration
 * @returns Array of raw round data
 */
export async function fetchExpressEntryRounds(
  config: IrccConfig = {}
): Promise<RawExpressEntryRound[]> {
  // NOTE: Canada.ca Express Entry rounds page requires JavaScript to load
  // data. This is a placeholder structure for when IRCC provides a proper API.
  //
  // Current approach:
  // 1. Ministerial Instructions page has historical data in table format
  // 2. Pool statistics are embedded in the rounds page
  // 3. Both require HTML parsing
  //
  // For now, return empty structure to demonstrate the fetcher pattern.

  return [];
}

/**
 * Fetch Express Entry pool statistics from Canada.ca.
 *
 * @param config - Fetch configuration
 * @returns Pool statistics data
 */
export async function fetchExpressEntryPoolStats(
  config: IrccConfig = {}
): Promise<Record<string, number>> {
  // NOTE: Pool statistics are embedded in HTML table on Canada.ca
  // Requires parsing of score distribution table

  return {};
}