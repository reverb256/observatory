export const FILINGS_USER_AGENT = 'MapleSpike-CorporateFilings/1.0';
export const FILINGS_TIMEOUT_MS = 15_000;
export const MAX_FILINGS = 200;
