export const FD_USER_AGENT = 'MapleSpike-FederalDeep/1.0';
export const FD_TIMEOUT_MS = 15_000;
export const CKAN_BASE = 'https://open.canada.ca/data/api/3/action';
export const CIHI_BASE = 'https://www.cihi.ca/sites/default/files/document';
export const CIHI_DATASETS = [
  'emergency-department-visits-apr-sep-2025-provisional-data-tables-en.xlsx',
  'wait-times-priority-procedures-in-canada-2025-data-tables-en.xlsx',
];
export const MAX_FEDERAL_RECORDS = 200;
