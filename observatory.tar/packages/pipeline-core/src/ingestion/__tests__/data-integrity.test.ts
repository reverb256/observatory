/**
 * Data Integrity Tests — MapleSpike Pipeline
 *
 * Validates citation hashing, trust scoring, cross-reference consistency,
 * module registry integration, database schema compliance, and source
 * trust score thresholds.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { buildCitation, buildMerkleRoot, generateMerkleProof } from '../attestation/index.js';
import { computeHash, verifyHash } from '../../verification/hashing.js';
import {
  DEFAULT_THRESHOLDS, evaluateThresholds, calculateTrustScore,
  computeTrustScore, TTRUST_SOURCE_SCORES,
} from '../../curation/scoring.js';
import { CROSS_REF_MODULES } from '../cross-reference/index.js';
import { getAllModules } from '../registry.js';
import { DND_DDL } from '../defence/constants.js';

/* ------------------------------------------------------------------ */
/*  1. Citation Hash Integrity                                         */
/* ------------------------------------------------------------------ */
describe('Citation Hash Integrity', () => {
  it('buildCitation produces a citation with dataHash', () => {
    const citation = buildCitation({
      sourceName: 'test-source',
      sourceUrl: 'https://example.com/data',
      dataHash: 'abc123',
    });
    assert.ok(citation.dataHash, 'citation must have dataHash');
    assert.equal(citation.sourceName, 'test-source');
    assert.equal(citation.sourceUrl, 'https://example.com/data');
    assert.ok(citation.retrievedAt, 'citation must have retrievedAt timestamp');
    assert.ok(citation.retrievedAt.includes('T'), 'retrievedAt must be ISO-8601');
  });

  it('buildCitation merges optional fields', () => {
    const citation = buildCitation({
      sourceName: 'src',
      sourceUrl: 'https://src.ca',
      dataHash: 'def456',
      updateFrequency: 'daily',
      license: 'OGL-Canada',
    });
    assert.equal(citation.updateFrequency, 'daily');
    assert.equal(citation.license, 'OGL-Canada');
  });

  it('buildCitation uses default license when not provided', () => {
    const citation = buildCitation({
      sourceName: 'src',
      sourceUrl: 'https://src.ca',
      dataHash: 'xyz',
    });
    assert.ok(citation.license.includes('Open Government'));
  });

  it('computeHash returns 64-character SHA-256 hex string', async () => {
    const hash = await computeHash('test content', 'sha256');
    assert.equal(hash.length, 64, 'SHA-256 must be 64 hex chars');
    assert.ok(/^[a-f0-9]{64}$/.test(hash), 'hash must be lowercase hex');
  });

  it('computeHash supports sha384', async () => {
    const hash = await computeHash('test content', 'sha384');
    assert.equal(hash.length, 96, 'SHA-384 must be 96 hex chars');
  });

  it('computeHash supports sha512', async () => {
    const hash = await computeHash('test content', 'sha512');
    assert.equal(hash.length, 128, 'SHA-512 must be 128 hex chars');
  });

  it('verifyHash returns true for matching content', async () => {
    const content = 'verify me';
    const hash = await computeHash(content, 'sha256');
    const result = await verifyHash(content, hash, 'sha256');
    assert.equal(result, true);
  });

  it('verifyHash returns false for mismatched content', async () => {
    const hash = await computeHash('original', 'sha256');
    const result = await verifyHash('tampered', hash, 'sha256');
    assert.equal(result, false);
  });

  it('computeHash is deterministic', async () => {
    const a = await computeHash('deterministic test', 'sha256');
    const b = await computeHash('deterministic test', 'sha256');
    assert.equal(a, b);
  });

  it('buildMerkleRoot handles single record', async () => {
    const hash = await computeHash('single record', 'sha256');
    const { root, tree } = await buildMerkleRoot([hash]);
    assert.equal(root, hash, 'single-record root must equal the leaf hash');
    assert.equal(tree.length, 1);
    assert.equal(tree[0].length, 1);
  });

  it('buildMerkleRoot produces consistent root for same hashes', async () => {
    const hashes = [
      await computeHash('a', 'sha256'),
      await computeHash('b', 'sha256'),
      await computeHash('c', 'sha256'),
    ];
    const r1 = await buildMerkleRoot(hashes);
    const r2 = await buildMerkleRoot(hashes);
    assert.equal(r1.root, r2.root, 'Merkle roots must be deterministic');
    assert.ok(r1.tree.length >= 2, 'multi-record tree must have >1 level');
  });

  it('buildMerkleRoot handles empty input', async () => {
    const { root, tree } = await buildMerkleRoot([]);
    assert.ok(root, 'empty input must still produce a root');
    assert.equal(root.length, 64);
    assert.equal(tree.length, 1);
  });

  it('generateMerkleProof returns null for unknown leaf', () => {
    const proof = generateMerkleProof('nonexistent', [['a', 'b'], ['c']]);
    assert.equal(proof, null);
  });

  it('generateMerkleProof returns siblings for existing leaf', async () => {
    const hashes = [
      await computeHash('x', 'sha256'),
      await computeHash('y', 'sha256'),
    ];
    const { tree } = await buildMerkleRoot(hashes);
    const proof = generateMerkleProof(hashes[0], tree);
    assert.ok(proof !== null, 'proof must exist for valid leaf');
    assert.equal(proof.index, 0);
    assert.ok(proof.siblings.length >= 1);
  });
});

/* ------------------------------------------------------------------ */
/*  2. Trust Score Thresholds                                         */
/* ------------------------------------------------------------------ */
describe('Trust Score Thresholds', () => {
  it('DEFAULT_THRESHOLDS has all three values ≥ 60', () => {
    const vals = [DEFAULT_THRESHOLDS.canadianRelevance, DEFAULT_THRESHOLDS.accountabilityValue, DEFAULT_THRESHOLDS.missionAlignment];
    for (const v of vals) {
      assert.ok(v >= 60, `threshold value ${v} must be ≥ 60`);
    }
  });

  it('DEFAULT_THRESHOLDS has canadianRelevance >= accountabilityValue', () => {
    assert.ok(DEFAULT_THRESHOLDS.canadianRelevance >= DEFAULT_THRESHOLDS.accountabilityValue);
  });

  it('calculateTrustScore uses correct weight math (25/25/20/15/15)', () => {
    const score = calculateTrustScore({
      canadianRelevance: 100,
      accountabilityValue: 100,
      missionAlignment: 100,
      sourceQuality: 100,
      urgency: 100,
    });
    assert.equal(score, 100, 'all-100 must produce 100');

    const half = calculateTrustScore({
      canadianRelevance: 50,
      accountabilityValue: 50,
      missionAlignment: 50,
      sourceQuality: 50,
      urgency: 50,
    });
    assert.equal(half, 50, 'all-50 must produce 50');

    // Weight verification: sourceQuality * 0.15 + urgency * 0.15 = 30 * 0.3 = 9
    const weightCheck = calculateTrustScore({
      canadianRelevance: 0,
      accountabilityValue: 0,
      missionAlignment: 0,
      sourceQuality: 100,
      urgency: 100,
    });
    assert.equal(weightCheck, 30, 'sourceQuality+urgency at 30% weight');
  });

  it('evaluateThresholds returns true when below threshold (should reject)', () => {
    const reject = evaluateThresholds({
      canadianRelevance: 0,
      accountabilityValue: 0,
      missionAlignment: 60,
    });
    assert.equal(reject, true, 'should reject when canadianRelevance is 0');
  });

  it('evaluateThresholds returns false when all dimensions meet thresholds', () => {
    const pass = evaluateThresholds({
      canadianRelevance: 100,
      accountabilityValue: 100,
      missionAlignment: 100,
    });
    assert.equal(pass, false, 'should NOT reject when all dimensions pass');
  });

  it('evaluateThresholds uses custom thresholds when provided', () => {
    const strictPass = evaluateThresholds(
      { canadianRelevance: 85, accountabilityValue: 85, missionAlignment: 85 },
      { canadianRelevance: 90, accountabilityValue: 90, missionAlignment: 90 },
    );
    assert.equal(strictPass, true, 'should reject under stricter thresholds');
  });

  it('computeTrustScore returns 95 for canada.ca', () => {
    assert.equal(computeTrustScore('https://www.canada.ca/data'), 95);
  });

  it('computeTrustScore returns 50 for unknown source', () => {
    assert.equal(computeTrustScore('https://unknown-source.example.com'), 50);
  });

  it('computeTrustScore handles bare domains', () => {
    assert.equal(computeTrustScore('statcan.gc.ca'), 95);
    assert.equal(computeTrustScore('cbc.ca'), 80);
  });

  it('computeTrustScore is case-insensitive', () => {
    assert.equal(computeTrustScore('HTTPS://STATCAN.GC.CA'), 95);
  });
});

/* ------------------------------------------------------------------ */
/*  3. Cross-Reference Consistency                                     */
/* ------------------------------------------------------------------ */
describe('Cross-Reference Consistency', () => {
  it('CROSS_REF_MODULES has 7 entries', () => {
    assert.equal(CROSS_REF_MODULES.length, 7);
  });

  it('CROSS_REF_MODULES has unique priorities (1-7)', () => {
    const priorities = CROSS_REF_MODULES.map(m => m.priority);
    const unique = new Set(priorities);
    assert.equal(unique.size, priorities.length, 'priorities must be unique');
    assert.deepEqual(priorities, [1, 2, 3, 4, 5, 6, 7], 'priorities must be 1-7 in order');
  });

  it('all CROSS_REF_MODULES have required fields', () => {
    for (const mod of CROSS_REF_MODULES) {
      assert.ok(typeof mod.id === 'string' && mod.id.length > 0, `entry missing valid id`);
      assert.ok(typeof mod.name === 'string' && mod.name.length > 0, `entry "${mod.id}" missing valid name`);
      assert.ok(typeof mod.priority === 'number' && mod.priority >= 1, `entry "${mod.id}" missing valid priority`);
    }
  });

  it('CROSS_REF_MODULES entries match as const shape', () => {
    // `as const` is compile-time only (no runtime freeze)
    // Verify structural integrity: each entry has required fields with correct types
    for (const mod of CROSS_REF_MODULES) {
      assert.equal(typeof mod.id, 'string');
      assert.equal(typeof mod.name, 'string');
      assert.equal(typeof mod.priority, 'number');
      assert.ok(Number.isInteger(mod.priority) && mod.priority >= 1);
    }
  });
});

/* ------------------------------------------------------------------ */
/*  4. Module Registry Integration                                     */
/* ------------------------------------------------------------------ */
describe('Module Registry Integration', () => {
  const allModules = getAllModules();
  const names = allModules.map(m => m.name);

  it('all cross-ref modules are registered in the module registry', () => {
    for (const cr of CROSS_REF_MODULES) {
      // 'lobbying' is part of 'corporate' module, not standalone
      if (cr.id === 'lobbying') continue;
      const id = cr.id;
      assert.ok(names.includes(id), `cross-ref module "${id}" not found in registry`);
    }
  });

  it('attestation module exports buildCitation', () => {
    assert.ok(typeof buildCitation === 'function', 'attestation must export buildCitation');
  });

  it('cross-reference module exports searchCrossReference', async () => {
    const { searchCrossReference } = await import('../cross-reference/index.js');
    assert.ok(typeof searchCrossReference === 'function', 'cross-reference must export searchCrossReference');
  });

  it('cross-reference module re-exports CROSS_REF_MODULES', () => {
    assert.ok(Array.isArray(CROSS_REF_MODULES));
  });

  it('CROSS_REF_MODULES module names match registry names', () => {
    for (const cr of CROSS_REF_MODULES) {
      // 'lobbying' is part of 'corporate' module, not standalone
      if (cr.id === 'lobbying') continue;
      const reg = allModules.find(m => m.name === cr.id);
      assert.ok(reg, `cross-ref module "${cr.id}" is not in registry`);
      assert.ok(reg.ingestFunctions.length > 0, `registry entry for "${cr.id}" has no ingest functions`);
    }
  });
});

/* ------------------------------------------------------------------ */
/*  5. Database Schema Compliance (skip gracefully if no DB)          */
/* ------------------------------------------------------------------ */
describe('Database Schema Compliance', () => {
  const SCHEMA_DIR = new URL('../../../database/', import.meta.url).pathname;

  it('defence DDL contains citation_hash column', () => {
    assert.ok(DND_DDL.includes('citation_hash'), 'defence DDL must include citation_hash column');
    assert.ok(DND_DDL.includes('CREATE TABLE'), 'defence DDL must have CREATE TABLE');
    assert.ok(DND_DDL.includes('defence_records'), 'defence DDL must create defence_records table');
  });

  it('citation_hashes schema file exists (if schemas dir present)', () => {
    // Skip gracefully if database/schema dir doesn't exist
    if (fs.existsSync(SCHEMA_DIR)) {
      const schemaFiles = fs.readdirSync(SCHEMA_DIR);
      const hasCitationTable = schemaFiles.some(f =>
        f.includes('citation') || f.includes('hash'),
      ) || schemaFiles.some(f => {
        const content = fs.readFileSync(path.join(SCHEMA_DIR, f), 'utf-8');
        return content.includes('citation_hashes') || content.includes('citation_hash');
      });
      // Informational only — don't fail tests
      console.log(`  ℹ  citation_hashes schema ${hasCitationTable ? 'found' : 'not found'} in ${SCHEMA_DIR}`);
    } else {
      console.log(`  ℹ  Schema directory ${SCHEMA_DIR} not found — skipping DB schema check`);
    }
  });
});

/* ------------------------------------------------------------------ */
/*  6. Source Trust Score Compliance                                   */
/* ------------------------------------------------------------------ */
describe('Source Trust Score Compliance', () => {
  it('all non-adversarial TTRUST_SOURCE_SCORES values are ≥ 60', () => {
    // Adversarial sources intentionally have very low scores
    const adversarialSources = ['rt.com', 'sputniknews.com', 'tass.com',
      'xinhuanet.com', 'cgtn.com', 'farsnews.ir', 'presstv.ir'];
    const entries = Object.entries(TTRUST_SOURCE_SCORES);
    for (const [source, score] of entries) {
      if (adversarialSources.includes(source)) continue;
      assert.ok(score >= 60,
        `"${source}" has trust score ${score}, expected ≥ 60`);
    }
  });

  it('government sources (.gc.ca, pm.gc.ca) have score ≥ 80', () => {
    const govSources = Object.entries(TTRUST_SOURCE_SCORES)
      .filter(([source]) => source.includes('gc.ca'));
    for (const [source, score] of govSources) {
      assert.ok(score >= 80,
        `Government source "${source}" has score ${score}, expected ≥ 80`);
    }
  });

  it('Canadian major media sources (cbc.ca, globeandmail.com, lapresse.ca) have score ≥ 75', () => {
    const mediaSources = ['cbc.ca', 'globeandmail.com', 'lapresse.ca'];
    for (const src of mediaSources) {
      if (TTRUST_SOURCE_SCORES[src] !== undefined) {
        assert.ok(TTRUST_SOURCE_SCORES[src] >= 75,
          `Media source "${src}" score ${TTRUST_SOURCE_SCORES[src]} < 75`);
      }
    }
  });

  it('adversarial sources (rt.com, sputniknews.com, tass.com) have score ≤ 15', () => {
    const advSources = ['rt.com', 'sputniknews.com', 'tass.com', 'xinhuanet.com', 'cgtn.com', 'farsnews.ir', 'presstv.ir'];
    for (const src of advSources) {
      if (TTRUST_SOURCE_SCORES[src] !== undefined) {
        assert.ok(TTRUST_SOURCE_SCORES[src] <= 15,
          `Adversarial source "${src}" score ${TTRUST_SOURCE_SCORES[src]} should be ≤ 15`);
      }
    }
  });

  it('computeTrustScore returns independent result for each known source', () => {
    const sources = ['reuters.com', 'bbc.com', 'apnews.com'];
    for (const src of sources) {
      const score = computeTrustScore(`https://${src}/some/path`);
      assert.ok(score >= 70, `"${src}" trust score ${score} should be ≥ 70`);
    }
  });
});
