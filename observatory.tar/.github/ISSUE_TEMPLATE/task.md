---
name: Task / Chore
about: Track a defined unit of work
title: ''
labels: ''
assignees: ''
---

## Task
One-line summary.

## Steps
- [ ] Step 1
- [ ] Step 2
- [ ] Verification

## Context
Why is this needed?

## Workflow
- [ ] Single PR per task
- [ ] Work in worktree (`git worktree add -b issue-NNN-desc /data/projects/own/maplespike-NNN main`)
- [ ] Branch: `issue-NNN-short-description`
- [ ] Commit messages reference `(#NNN)`
- [ ] PR body contains `Closes #NNN`
- [ ] PR reviewed before merge (even solo)

## Reference
- Related issue: #
- ROADMAP.md section:
