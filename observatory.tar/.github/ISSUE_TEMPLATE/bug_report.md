---
name: Bug report
about: Something isn't working
title: ''
labels: bug
assignees: ''
---

## Describe the Bug
Clear and concise description.

## To Reproduce
Steps to reproduce.

## Expected vs Actual
What should happen vs what actually happens.

## Environment
- **Package:** [pipeline-core / mcp-server / api-server / portal / engine / sdk / other]
- **Working node:** [zephyr / nexus / forge / sentry]
- **Worktree path:** `/data/projects/own/maplespike-<NNN>`
- **Branch:** `issue-NNN-short-description`
- **Commit:** `git log -1 --oneline`
- **Node version:** `node --version`

## Logs / Screenshots
```
Paste relevant output
```

## Workflow Check
- [ ] Issue created before any code was written
- [ ] Work in a worktree (`git worktree add`)
- [ ] Branch name follows `issue-NNN-short-description`
- [ ] PR will be created before merge

## Additional Context
- Is this a regression?
- Link to related issue: #
